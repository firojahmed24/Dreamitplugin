
(function( $ ) {
    'use strict';




    $(window).scroll(function () {
        if($(window).scrollTop() > 30) {
            $(".transparent-menu").addClass('sticky');
        } else {
            $(".transparent-menu").removeClass('sticky');
        }
    });




 })( jQuery );