<?php

use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

if(!defined('ABSPATH')) exit;


class ServiceList extends \Elementor\Widget_Base{

	public function get_name(){
		return "ServiceList";
	}
	
	public function get_title(){
		return "ServiceList";
	}
	
	public function get_icon(){
		return "eicon-bullet-list";
	}

	public function get_categories(){
		return ['dreamit-category'];
	}

	protected function register_controls() {
		
        $this->start_controls_section(
			'slider', [
				'label' => __( 'Slider', 'dreamit-elementor-extension' ),
			]
		);

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'service_style',
            [
                'label' => __( 'Slider style', 'dreamit-elementor-extension' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'style_01' => esc_html__('Style one', 'dreamit-elementor-extension'),
                    'style_02' => esc_html__('Style two', 'dreamit-elementor-extension'),
                ],
                'default' => 'style_01'
            ],
        ); 
        $repeater->add_control(
			'subtitle',
            [
                'label' => __( 'Subtitle', 'dreamit-elementor-extension' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Welcome to dreamhub'
            ],
		);        
        $repeater->add_control(
			'title',
            [
                'label' => __( 'Title', 'dreamit-elementor-extension' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'We are a creative <br>Design Agency',
            ],
		);
          $repeater->add_control(
            'single_image',
            [
                'label' => __( 'Choose Single Image', 'dreamit-elementor-extension' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
            ],  
        );        
        $repeater->add_control(
            'number',
            [
                'label' => __( 'Number', 'dreamit-elementor-extension' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => '00 +88012 222 333'
            ],
        );
		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Slide Items', 'dreamit-elementor-extension' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
			]
		);


        $this->end_controls_section();


        /**
         * Style Tab
         */

        $this->start_controls_section(
            'general_section', [
                'label' => __( 'General', 'dreamit-elementor-extension' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->end_controls_section();

        //------------------------------ Style Title ------------------------------
        $this->start_controls_section(
            'style_title', [
                'label' => __( 'Title', 'dreamit-elementor-extension' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'color_title', [
                'label' => __( 'Text Color', 'dreamit-elementor-extension' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-text h3' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .slider_two .service-text h3' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'typography_title',
                
                'selector' => '{{WRAPPER}} .service-text h3, {{WRAPPER}}  .service-text h3',
            ]
        );
        $this->end_controls_section();


        //------------------------------ Style subtitle ------------------------------
        $this->start_controls_section(
            'style_subtitle', [
                'label' => __( 'Subtitle', 'dreamit-elementor-extension' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'color_subtitle', [
                'label' => __( 'Text Color', 'dreamit-elementor-extension' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-text h4' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .service-text h4' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'typography_subtitle',
                'selector' => '{{WRAPPER}} .service-text h4, {{WRAPPER}} .service-text h3',
            ]
        );
        $this->add_responsive_control(
            'subtitle_margin',
            [
                'label' => __( 'Margin', 'dreamit-elementor-extension' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .service-text h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();


        
	}


    protected function render() {

        $settings = $this->get_settings();

        ?>

        <section class="dreamit-service">
            <div class="default-service">
                <?php foreach ( $settings['list'] as $item  ) { ?>
                    <?php if($item['service_style']=='style_01'){ ?>
                      <div class="service_list style-1 align-items-center d-flex ">
                        <div class="service-text">
                            <?php if(!empty($item['image'])) : ?> <h4> <img src="<?php echo $item['single_image']['url'];?>"> <?php endif; ?>
                           <?php if(!empty($item['subtitle'])) : ?> <h4> <?php echo esc_html_e($item['subtitle']) ?> </h4> <?php endif; ?>
                           <?php if(!empty($item['title'])) : ?> <h3 class="font-600"> <?php echo $item['title']; ?> </h3> <?php endif; ?>
                       </div>

                   </div>
               <?php } elseif($item['service_style']=='style_02'){ ?>
                      <div class="service_list style-2 align-items-center d-flex ">
                        <div class="service-text">
                            <div class="image">
                                 <img src="<?php echo $item['single_image']['url']; ?>"> 
                            </div>
                            <?php if(!empty($item['subtitle'])) : ?> <h4> <?php echo esc_html_e($item['subtitle']) ?> </h4> <?php endif; ?>
                            <?php if(!empty($item['title'])) : ?> <h3 class="font-600"> <?php echo $item['title']; ?> </h3> <?php endif; ?>
                        </div>

                   </div>
               <?php }?>

            <?php } ?>
        </div>
    </section>


<?php }

}