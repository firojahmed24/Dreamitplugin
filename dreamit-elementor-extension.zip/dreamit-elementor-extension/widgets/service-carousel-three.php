<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if(!defined('ABSPATH')) exit;

class ServiceThree extends Widget_Base{

	public function get_name(){
		return "ServiceThree";
	}
	
	public function get_title(){
		return "ServiceThree";
	}
	
	public function get_icon(){
		return "eicon-product-related";
	}
	
	public function get_categories(){
		return ['dreamit-category'];
	}

	protected function register_controls(){

		$this->start_controls_section(
			'service_section',
			[
				'label' => esc_html__( 'Service', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'service_img',
			[
				'label' => esc_html__( 'Service Image', 'dreamit-elementor-extension' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'main_title',
			[
				'label' => __( 'Button Text', 'dreamit-elementor-extension' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your button text', 'dreamit-elementor-extension' ),
				'label_block' => true,
				'default' => __( 'Service Title', 'dreamit-elementor-extension' ),
			]
		);
		$repeater->add_control(
			'title_link',
			[
				'label' => __( 'Link', 'dreamit-elementor-extension' ),
				'type' => Controls_Manager::URL,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'https://your-link.com', 'dreamit-elementor-extension' ),
			]
		);
		$repeater->add_control(
			'service_sub_title', [
				'label' => esc_html__( 'Sub Title', 'dreamit-elementor-extension' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Service Sub Title' , 'dreamit-elementor-extension' ),
				'label_block' => true,
			]
		);
		
		$repeater->add_control(
			'service_list',
			[
				'label' => __( 'Price List', 'dreamit-elementor-extension' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Service' , 'dreamit-elementor-extension' ),
			]
		);
		$repeater->add_control(
			'service_list2',
			[
				'label' => __( 'Price List', 'dreamit-elementor-extension' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Service' , 'dreamit-elementor-extension' ),
			]
		);
		$repeater->add_control(
			'service_list3',
			[
				'label' => __( 'Price List', 'dreamit-elementor-extension' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Service' , 'dreamit-elementor-extension' ),
			]
		);

		$repeater->add_control(
				'button_text',
				[
					'label' => __( 'Button Text', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Enter your button text', 'dreamit-elementor-extension' ),
					'label_block' => true,
					'default' => __( 'Button', 'dreamit-elementor-extension' ),
				]
			);
			$repeater->add_control(
				'link',
				[
					'label' => __( 'Link', 'dreamit-elementor-extension' ),
					'type' => Controls_Manager::URL,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'https://your-link.com', 'dreamit-elementor-extension' ),
				]
			);
			$repeater->add_control(
				'show_button',
				[
					'label' => __( 'Show Button', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __( 'Show', 'dreamit-elementor-extension' ),
					'label_off' => __( 'Hide', 'dreamit-elementor-extension' ),
					'return_value' => 'yes',
					'default' => 'yes',
				]
			);
			$repeater->add_control(
			'button_icon',
			[
				'label' => esc_html__( 'Button Icon', 'dreamit-elementor-extension' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-circle',
					'library' => 'fa-solid',
				],
				'recommended' => [
					'fa-solid' => [
						'circle',
						'dot-circle',
						'square-full',
					],
					'fa-regular' => [
						'circle',
						'dot-circle',
						'square-full',
					],
				],
			]
		);
		$this->add_control(
			'service_list',
			[
				'label' => esc_html__( 'Service List', 'dreamit-elementor-extension' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'service_name' => esc_html__( 'Title #1', 'dreamit-elementor-extension' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'dreamit-elementor-extension' ),
					],
					[
						'service_name' => esc_html__( 'Title #2', 'dreamit-elementor-extension' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'dreamit-elementor-extension' ),
					],
				],
				'title_field' => '{{{ service_name }}}',
			]
		);

		$this->end_controls_section();

/*
==========
Style Tab
==========
*/

		$this->start_controls_section(
			'style_section',
			[
				'label' => __( 'Style', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'select_style',
				[
					'label' => __( 'Select Style', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'one' => __( 'One', 'dreamit-elementor-extension' ),
						'two' => __( 'Two', 'dreamit-elementor-extension' ),
						'three' => __( 'Three', 'dreamit-elementor-extension' ),
					],
					'default' => 'one',
					
				]
			);
		$this->add_responsive_control(
				'text_align',
				[
					'label' => __( 'Alignment', 'dreamit-elementor-extension' ),
					'type' => Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'dreamit-elementor-extension' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'dreamit-elementor-extension' ),
							'icon' => 'eicon-text-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'dreamit-elementor-extension' ),
							'icon' => 'eicon-text-align-right',
						],
						'justify' => [
							'title' => __( 'Justified', 'dreamit-elementor-extension' ),
							'icon' => 'eicon-text-align-justify',
						],
					],
					'selectors' => [
						'{{WRAPPER}} .service_items' => 'text-align: {{VALUE}};',
					],
				]
			);
		$this->end_controls_section();
		$this->start_controls_section(
			'title_section_style',
			[
				'label' => __( 'Title', 'dreamit-elementor-extension' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'title_color',
				[
					'label' => __( 'Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .service_items .service_item_content h2' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .service_items .service_item_content h2, {{WRAPPER}} .elementor-icon-box-content .elementor-icon-box-title a',
				]
			);
			$this->add_responsive_control(
				'title_margin',
				[
					'label' => __( 'Margin', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service_items .service_item_content h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'subtitle_section_style',
			[
				'label' => __( 'Sub Title', 'dreamit-elementor-extension' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'subtitle_color',
				[
					'label' => __( 'Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .service_items .service_item_content h4' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'subtitle_typography',
					'selector' => '{{WRAPPER}} .service_items .service_item_content h4, {{WRAPPER}} .elementor-icon-box-content .elementor-icon-box-title a',
				]
			);
			$this->add_responsive_control(
				'subtitle_margin',
				[
					'label' => __( 'Margin', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service_items .service_item_content h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'list_section_style',
			[
				'label' => __( 'List', 'dreamit-elementor-extension' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'list_title_color',
				[
					'label' => __( 'Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .service_items .list_item ul li' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'list_title_color_typography',
					'selector' => '{{WRAPPER}} .service_items .list_item ul li, {{WRAPPER}} .elementor-icon-box-content .elementor-icon-box-title a',
				]
			);
			$this->add_responsive_control(
				'list_title_color_margin',
				[
					'label' => __( 'Margin', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service_items .list_item ul li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();
		$this->start_controls_section(
			'button_section_style',
			[
				'label' => __( 'Button', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->start_controls_tabs(
				'button_style_tabs'
			);
				$this->start_controls_tab(
					'button_style_normal_tab',
					[
						'label' => __( 'Normal', 'dreamit-elementor-extension' ),
					]
				);
				
					$this->add_control(
						'button_text_color',
						[
							'label' => __( 'Text Color', 'dreamit-elementor-extension' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
								'{{WRAPPER}} .service_item .room-details-button a' => 'color: {{VALUE}};',
							],
						]
					);
					$this->add_control(
						'button_background_color',
						[
							'label' => __( 'Background Color', 'dreamit-elementor-extension' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
								'{{WRAPPER}} .service_item .room-details-button a' => 'background-color: {{VALUE}};',
							],
						]
					);
					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'button_border',
							'label' => __( 'Border', 'dreamit-elementor-extension' ),
							'selector' => '{{WRAPPER}} .service_item .room-details-button a',
						]
					);
					$this->add_responsive_control(
						'button_border_radius',
						[
							'label' => __( 'Border Radius', 'dreamit-elementor-extension' ),
							'type' => \Elementor\Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', 'em', '%' ],
							'selectors' => [
								'{{WRAPPER}} .service_item .room-details-button a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
				$this->end_controls_tab();
				
				$this->start_controls_tab(
					'button_style_hover_tab',
					[
						'label' => __( 'Hover', 'dreamit-elementor-extension' ),
					]
				);

					$this->add_control(
						'hover_button_text_color',
						[
							'label' => __( 'Text Color', 'dreamit-elementor-extension' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
								'{{WRAPPER}} .service_item .room-details-button a:hover' => 'color: {{VALUE}};',
							],
						]
					);
					$this->add_control(
						'hover_button_background_color',
						[
							'label' => __( 'Background Color', 'dreamit-elementor-extension' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
								'{{WRAPPER}} .service_item .room-details-button a:hover' => 'background-color: {{VALUE}};',
							],
						]
					);
					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'hover_button_border',
							'label' => __( 'Border', 'dreamit-elementor-extension' ),
							'selector' => '{{WRAPPER}} .service_item .room-details-button a:hover',
						]
					);
					$this->add_responsive_control(
						'hover_button_border_radius',
						[
							'label' => __( 'Border Radius', 'dreamit-elementor-extension' ),
							'type' => \Elementor\Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', 'em', '%' ],
							'selectors' => [
								'{{WRAPPER}} .service_item .room-details-button a:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
				$this->end_controls_tab();
				
			$this->end_controls_tabs();

			$this->add_responsive_control(
				'button_margin',
				[
					'label' => __( 'Margin', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service_item .room-details-button a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'button_padding',
				[
					'label' => __( 'Padding', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service_item .room-details-button a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
			$this->add_control(
				'button_height',
				[
					'label' => __( 'Height', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .service_item .room-details-button a' => 'height: {{SIZE}}{{UNIT}};',
					],
				]
			);
			$this->add_control(
				'button_width',
				[
					'label' => __( 'Width', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .service_item .room-details-button a' => 'width: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'button_typography',
					'selector' => '{{WRAPPER}} .service_item .room-details-button a',
				]
			);

		$this->end_controls_section();


	}

	protected function render(){

		$settings = $this->get_settings_for_display();
		
		?>

			<?php if($settings['select_style']=='one'){ ?>
			<div class="service_item_one">
				<div class="service_carousel owl-carousel style_2">
					<?php foreach (  $settings['service_list'] as $item ) { ?>
						<div class="service_item style_one">
							<div class="service_item_img">
								<img src="<?php echo $item['service_img']['url']; ?>" alt="">
							</div>
							<div class="service_item_content">
								<h2><a href="<?php echo esc_url($item['title_link']['url']); ?>">
											<?php echo $item['main_title']; ?>"></a></h2>
								<!-- <h2 class="title"><?php echo $item['main_title'];?></h2> -->
								<h4 class="sub_title"><?php echo $item['service_sub_title'];?></h4>
								<div class="list_item">
									<ul>
										<li><?php echo $item['service_list'];?></li>
									</ul>
								</div>
								<div class="list_item">
									<ul>
										<li><?php echo $item['service_list2'];?></li>
									</ul>
								</div>
								<div class="list_item two">
									<ul>
										<li><?php echo $item['service_list3'];?></li>
									</ul>
								</div>
							</div>
							<?php if( 'yes'===$item['show_button'] ){ ?>
									<div class="room-details-button">
										<a href="<?php echo esc_url($item['link']['url']); ?>">
											<?php echo $item['button_text']; ?>
											<i <?php echo $this->get_render_attribute_string( 'j' ); ?>></i>
										</a>
									</div><!-- .service-btn	-->
								<?php } ?>
						</div>
						<?php } ?>
					</div>
				</div>
			<script>
				jQuery(document).ready(function($) {
					"use strict";
                    	
                    $('.service_carousel').owlCarousel({
                    	loop: true,
                    	autoplay: false,
                    	autoplayTimeout: 4000,
                    	dots: true,
                    	nav: false,
                    	navText: ["<i class='flaticon flaticon-left-arrow'></i>", "<i class='flaticon flaticon-right-arrow''></i>"],
                    	responsive: {
                    		0: {
                    			items: 1
                    		},
                    		768: {
                    			items: 2
                    		},
                    		992: {
                    			items: 2
                    		},
                    		1500: {
                    			items: 3
                    		},
                    		1500: {
                    			items: 3
                    		},
                    		1920: {
                    			items: 3
                    		}
                    	}
                    })
				});
			</script>

			<?php } elseif($settings['select_style']=='two'){ ?>
			<div class="service_item_two">
				<div class="service_carousel owl-carousel style_2">
					<?php foreach (  $settings['service_list'] as $item ) { ?>
						<div class="single_service_items style_two">
						<div class="service_items style_two">
							<div class="service_item_img">
								<img src="<?php echo $item['service_img']['url']; ?>" alt="">
							</div>
							<div class="service_item_content">
								<h2><a href="<?php echo esc_url($item['title_link']['url']); ?>">
											<?php echo $item['main_title']; ?></a></h2>
								<h4 class="sub_title"><?php echo $item['service_sub_title'];?></h4>
								<div class="list_item">
									<ul>
										<li><?php echo $item['service_list'];?></li>
									</ul>
								</div>
								<div class="list_item">
									<ul>
										<li><?php echo $item['service_list2'];?></li>
									</ul>
								</div>
								<div class="list_item two">
									<ul>
										<li><?php echo $item['service_list3'];?></li>
									</ul>
								</div>
							</div>
							<?php if( 'yes'===$item['show_button'] ){ ?>
									<div class="room-details-button">
										<a href="<?php echo esc_url($item['link']['url']); ?>">
											<?php echo $item['button_text']; ?>
											<i <?php echo $this->get_render_attribute_string( 'j' ); ?>></i>
										</a>
									</div><!-- .service-btn	-->
								<?php } ?>
						</div>
						</div>
						<?php } ?>
					</div>
				</div>
			<script>
				jQuery(document).ready(function($) {
					"use strict";
                    	
                    $('.service_carousel').owlCarousel({
                    	loop: true,
                    	autoplay: false,
                    	autoplayTimeout: 4000,
                    	dots: true,
                    	center:true,
                    	nav: false,
                    	navText: ["<i class='flaticon flaticon-left-arrow'></i>", "<i class='flaticon flaticon-right-arrow''></i>"],
                    	responsive: {
                    		0: {
                    			items: 1
                    		},
                    		768: {
                    			items: 2
                    		},
                    		992: {
                    			items: 2
                    		},
                    		1500: {
                    			items: 3
                    		},
                    		1500: {
                    			items: 3
                    		},
                    		1920: {
                    			items: 3
                    		}
                    	}
                    })
				});
			</script>

			<?php }
			
			elseif($settings['select_style']=='three'){ ?>
			<div class="service_item_two style_3">
				<div class="service_carousel3 owl-carousel style_3">
					<?php foreach (  $settings['service_list'] as $item ) { ?>
						<div class="single_service_items style_3">
						<div class="service_items style_3">
							<div class="service_item_img">
								<img src="<?php echo $item['service_img']['url']; ?>" alt="">
							</div>
							<div class="service_item_content">
								<h2><a href="<?php echo esc_url($item['title_link']['url']); ?>">
											<?php echo $item['main_title']; ?></a></h2>
								<h4 class="sub_title"><?php echo $item['service_sub_title'];?></h4>
								
							</div>
							
						</div>
						</div>
						<?php } ?>
					</div>
				</div>
			<script>
				jQuery(document).ready(function($) {
					"use strict";
                    	
                    $('.service_carousel3').owlCarousel({
                    	loop: true,
                    	autoplay: true,
                    	autoplayTimeout: 4000,
                    	smartSpeed: 1500,
                    	dots: false,
                    	center:true,
                    	nav: false,
                    	navText: ["<i class='flaticon flaticon-left-arrow'></i>", "<i class='flaticon flaticon-right-arrow''></i>"],
                    	responsive: {
                    		0: {
                    			items: 1
                    		},
                    		768: {
                    			items: 2
                    		},
                    		992: {
                    			items: 2
                    		},
                    		1500: {
                    			items: 3
                    		},
                    		1500: {
                    			items: 3
                    		},
                    		1920: {
                    			items: 3
                    		}
                    	}
                    })
				});
			</script>

			<?php }?>

		<?php
	}
	
}