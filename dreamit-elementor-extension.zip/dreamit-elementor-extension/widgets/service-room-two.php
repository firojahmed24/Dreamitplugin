<?php

if(!defined('ABSPATH')) exit;

class ServiceRoomTwo extends \Elementor\Widget_Base{

	public function get_name(){
		return "ServiceRoomTwo";
	}
	
	public function get_title(){
		return "Service Room Two";
	}
	
	public function get_icon(){
		return "eicon-kit-parts";
	}

	public function get_categories(){
		return ['dreamit-category'];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'package_section',
			[
				'label' => __( 'Package Info', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'single_img_room',
				[
				    'label' => esc_html__('Image','dreamit-elementor-extension'),
				    'type'=> \Elementor\Controls_Manager::MEDIA,
				    'default' => [
					  'url' => \Elementor\Utils::get_placeholder_image_src(),
				    ],
				]
			);
			
			
			$this->add_control(
				'rating',
				[
					'label' => esc_html__( 'Rating', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::NUMBER,
					'min' => 1,
					'max' => 5,
					'step' => 1,
					'default' => 3,
				]
			);
			
			
			$this->add_control(
				'room_title',
				[
					'label' => esc_html__( 'Title', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Default title', 'dreamit-elementor-extension' ),
					'placeholder' => esc_html__( 'Type your title here', 'dreamit-elementor-extension' ),
					'label_block' => true,
				]
			);
			$this->add_control(
				'room_description',
				[
					'label' => esc_html__( 'Description', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 5,
					'default' => esc_html__( 'Default description', 'dreamit-elementor-extension' ),
					'placeholder' => esc_html__( 'Type your description here', 'dreamit-elementor-extension' ),
				]
			);
        $this->add_control(
			'room_price',
			[
				'label' => __( 'Room Price', 'dreamit-elementor-extension' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( '50', 'dreamit-elementor-extension' ),
				'placeholder' => __( '50', 'dreamit-elementor-extension' ),
			]
		);
		$this->add_control(
			'room_price_title',
			[
				'label' => __( 'Room Price Title', 'dreamit-elementor-extension' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Give Price', 'dreamit-elementor-extension' ),
				'placeholder' => __( 'Give Price', 'dreamit-elementor-extension' ),
			]
		);
		
		
		
			$this->add_control(
				'icons_type',
				[
				    'label' => esc_html__('Icon Type','dreamit-elementor-extension'),
				    'type' => \Elementor\Controls_Manager::CHOOSE,
				    'options' =>[
					  'img' =>[
						'title' =>esc_html__('Image','dreamit-elementor-extension'),
						'icon' =>'fa fa-picture-o',
					  ],
					  'icon' =>[
						'title' =>esc_html__('Icon','dreamit-elementor-extension'),
						'icon' =>'fa fa-info',
					  ]
				    ],
				    'default' => 'icon',
				]
			 );
			 	
			 	
			 	
			 $this->add_control(
				'select_icon',
				[
					'label' => esc_html__( 'Icon', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'condition'=>[
						'icons_type'=> 'icon',
					],
					'label_block' => true,
				]
			);
			
			$this->add_control(
				'select_img',
				[
				    'label' => esc_html__('Image','dreamit-elementor-extension'),
				    'type'=> \Elementor\Controls_Manager::MEDIA,
				    'default' => [
					  'url' => \Elementor\Utils::get_placeholder_image_src(),
				    ],
				    'condition' => [
					  'icons_type' => 'img',
				    ]
				]
			);
			
			$this->add_control(
				'place_title',
				[
					'label' => esc_html__( 'Title', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Default title', 'dreamit-elementor-extension' ),
					'placeholder' => esc_html__( 'Type your title here', 'dreamit-elementor-extension' ),
					'label_block' => true,
				]
			);
			
			
			
			
			$this->add_control(
				'icons_type_two',
				[
				    'label' => esc_html__('Icon Type','dreamit-elementor-extension'),
				    'type' => \Elementor\Controls_Manager::CHOOSE,
				    'options' =>[
					  'img' =>[
						'title' =>esc_html__('Image','dreamit-elementor-extension'),
						'icon' =>'fa fa-picture-o',
					  ],
					  'icon' =>[
						'title' =>esc_html__('Icon','dreamit-elementor-extension'),
						'icon' =>'fa fa-info',
					  ]
				    ],
				    'default' => 'icon',
				]
			 );
			 	
			 $this->add_control(
				'select_icon_two',
				[
					'label' => esc_html__( 'Icon', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'condition'=>[
						'icons_type'=> 'icon',
					],
					'label_block' => true,
				]
			);
			
			$this->add_control(
				'select_img_two',
				[
				    'label' => esc_html__('Image','dreamit-elementor-extension'),
				    'type'=> \Elementor\Controls_Manager::MEDIA,
				    'default' => [
					  'url' => \Elementor\Utils::get_placeholder_image_src(),
				    ],
				    'condition' => [
					  'icons_type' => 'img',
				    ]
				]
			);
			
			
			$this->add_control(
				'plane_title',
				[
					'label' => esc_html__( 'Title', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Default title', 'dreamit-elementor-extension' ),
					'placeholder' => esc_html__( 'Type your title here', 'dreamit-elementor-extension' ),
					'label_block' => true,
				]
			);
			
			
			
			$this->add_control(
				'icons_type_three',
				[
				    'label' => esc_html__('Icon Type','dreamit-elementor-extension'),
				    'type' => \Elementor\Controls_Manager::CHOOSE,
				    'options' =>[
					  'img' =>[
						'title' =>esc_html__('Image','dreamit-elementor-extension'),
						'icon' =>'fa fa-picture-o',
					  ],
					  'icon' =>[
						'title' =>esc_html__('Icon','dreamit-elementor-extension'),
						'icon' =>'fa fa-info',
					  ]
				    ],
				    'default' => 'icon',
				]
			 );
			 	
			 $this->add_control(
				'select_icon_three',
				[
					'label' => esc_html__( 'Icon', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'condition'=>[
						'icons_type'=> 'icon',
					],
					'label_block' => true,
				]
			);
			
			$this->add_control(
				'select_img_three',
				[
				    'label' => esc_html__('Image','dreamit-elementor-extension'),
				    'type'=> \Elementor\Controls_Manager::MEDIA,
				    'default' => [
					  'url' => \Elementor\Utils::get_placeholder_image_src(),
				    ],
				    'condition' => [
					  'icons_type' => 'img',
				    ]
				]
			);
			
			
			$this->add_control(
				'plane_title_three',
				[
					'label' => esc_html__( 'Title', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Default title', 'dreamit-elementor-extension' ),
					'placeholder' => esc_html__( 'Type your title here', 'dreamit-elementor-extension' ),
					'label_block' => true,
				]
			);
			
			
			$this->add_control(
				'icons_type_four',
				[
				    'label' => esc_html__('Icon Type','dreamit-elementor-extension'),
				    'type' => \Elementor\Controls_Manager::CHOOSE,
				    'options' =>[
					  'img' =>[
						'title' =>esc_html__('Image','dreamit-elementor-extension'),
						'icon' =>'fa fa-picture-o',
					  ],
					  'icon' =>[
						'title' =>esc_html__('Icon','dreamit-elementor-extension'),
						'icon' =>'fa fa-info',
					  ]
				    ],
				    'default' => 'icon',
				]
			 );
			 	
			 $this->add_control(
				'select_icon_four',
				[
					'label' => esc_html__( 'Icon', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'condition'=>[
						'icons_type'=> 'icon',
					],
					'label_block' => true,
				]
			);
			
			$this->add_control(
				'select_img_four',
				[
				    'label' => esc_html__('Image','dreamit-elementor-extension'),
				    'type'=> \Elementor\Controls_Manager::MEDIA,
				    'default' => [
					  'url' => \Elementor\Utils::get_placeholder_image_src(),
				    ],
				    'condition' => [
					  'icons_type' => 'img',
				    ]
				]
			);
			
			
			$this->add_control(
				'plane_title_four',
				[
					'label' => esc_html__( 'Title', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Default title', 'dreamit-elementor-extension' ),
					'placeholder' => esc_html__( 'Type your title here', 'dreamit-elementor-extension' ),
					'label_block' => true,
				]
			);
			
		

		$this->end_controls_section();

		$this->start_controls_section(
			'button_section',
			[
				'label' => __( 'Button', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'button_text',
				[
					'label' => __( 'Text', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Click Here', 'dreamit-elementor-extension' ),
					'label_block' => true,
					'default' => __( 'Click Here', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'button_link',
				[
					'label' => __( 'Link', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'button_icon',
				[
					'label' => __( 'Icon', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::ICONS,
				]
			);

		$this->end_controls_section();


/**
 * Style Tab
 */

		$this->start_controls_section(
			'general_section',
			[
				'label' => __( 'General', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'select_style',
				[
					'label' => __( 'Select Style', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'one' => __( 'One', 'dreamit-elementor-extension' ),
						'two' => __( 'Two', 'dreamit-elementor-extension' ),
					],
					'default' => 'one',
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'price_style',
			[
				'label' => __( 'Package Price', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'price_color',
				[
					'label' => esc_html__( 'Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .service_room_two .room_pricing .dolar' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'price_typography',
					'label' => __( 'Typography', 'dreamit-elementor-extension' ),
					'selector' => '{{WRAPPER}} .service_room_two .room_pricing .dolar',
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'price_title_description_style',
			[
				'label' => __( 'Title & Description', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'price_title',
				[
					'label' => esc_html__( 'Price Title', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::HEADING,
				]
			);
			$this->add_control(
				'price_title_color',
				[
					'label' => __( 'Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .service_room_two .room_pricing .title' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'price_title_typography',
					'label' => __( 'Typography', 'dreamit-elementor-extension' ),
					'selector' => '{{WRAPPER}} .service_room_two .room_pricing .title',
				]
			);
			$this->add_responsive_control(
				'price_title_margin',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Margin', 'dreamit-elementor-extension' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service_room_two .room_pricing .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		$this->start_controls_section(
			'main_title_style',
			[
				'label' => __( 'Main Titlle', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'title_color',
				[
					'label' => __( 'Title Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .service_room_two .service_room_body h3' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'label' => __( 'Currency Typography', 'dreamit-elementor-extension' ),
					'selector' => '{{WRAPPER}} .service_room_two .service_room_body h3',
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'description_style',
			[
				'label' => __( 'Description', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'description_color',
				[
					'label' => __( 'Description Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .service_room_two .service_room_body p' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'description_typography',
					'label' => __( 'Price Typography', 'dreamit-elementor-extension' ),
					'selector' => '{{WRAPPER}} .service_room_two .service_room_body p',
				]
			);

		$this->end_controls_section();
		$this->start_controls_section(
			'list_title_style',
			[
				'label' => __( 'List Titlle', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'list_title_color',
				[
					'label' => __( 'List Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .service_room_two .service_room_body ul li' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'list_title_typography',
					'label' => __( 'Currency Typography', 'dreamit-elementor-extension' ),
					'selector' => '{{WRAPPER}} .service_room_two .service_room_body ul li',
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__( 'Button', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'button_typography',
					'selector' => '{{WRAPPER}} .service_room_two .room_btn a',
				]
			);

			$this->start_controls_tabs(
				'style_tabs'
			);

			$this->start_controls_tab(
				'style_normal_tab',
				[
					'label' => esc_html__( 'Normal', 'dreamit-elementor-extension' ),
				]
			);

			$this->add_control(
				'text_color',
				[
					'label' => esc_html__( 'Text Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .service_room_two .room_btn a' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Background::get_type(),
				[
					'name' => 'background',
					'label' => esc_html__( 'Background', 'dreamit-elementor-extension' ),
					'types' => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .service_room_two .room_btn a',
				]
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'style_hover_tab',
				[
					'label' => esc_html__( 'Hover', 'dreamit-elementor-extension' ),
				]
			);

			$this->add_control(
				'text_hover_color',
				[
					'label' => esc_html__( 'Text Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .service_room_two .room_btn a:hover' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Background::get_type(),
				[
					'name' => 'hover_background',
					'label' => esc_html__( 'Background', 'dreamit-elementor-extension' ),
					'types' => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .service_room_two .room_btn a:hover',
				]
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'button_border',
					'label' => esc_html__( 'Border', 'dreamit-elementor-extension' ),
					'selector' => '{{WRAPPER}} .service_room_two .room_btn a',
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'button_border_radius',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Border Radius', 'dreamit-elementor-extension' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service_room_two .room_btn a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'box_shadow',
					'label' => esc_html__( 'Box Shadow', 'dreamit-elementor-extension' ),
					'selector' => '{{WRAPPER}} .service_room_two .room_btn a',
				]
			);
			$this->add_responsive_control(
				'button_padding',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Padding', 'dreamit-elementor-extension' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service_room_two .room_btn a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		?>

		<?php if($settings['select_style']=='one'){ ?>
			<div class="service_room_two style1 <?php if('yes' === $settings['show_active']){echo esc_attr('active');}?>">
				<div class="room_img">
					<img src="<?php echo $settings['single_img_room']['url']; ?>" alt="" />
				</div>
				
				
				<div class="service_room_body">
				    
				    <div class="room_star">
			    	<div class="reviews_rating">
					    <?php if( $settings['rating']==5 ){ ?>
					    	<div class="testi-star">
					    		<i class="fa fa-star active"></i>
					    		<i class="fa fa-star active"></i>
					    		<i class="fa fa-star active"></i>
					    		<i class="fa fa-star active"></i>
					    		<i class="fa fa-star active"></i>
					    	</div>
					<?php } ?>

					<?php if( $settings['rating']==4 ){ ?>
						<div class="testi-star">
							<i class="fa fa-star active"></i>
							<i class="fa fa-star active"></i>
							<i class="fa fa-star active"></i>
							<i class="fa fa-star active"></i>
							<i class="fa fa-star"></i>
						</div>
					<?php } ?>

					<?php if( $settings['rating']==3 ){ ?>
						<div class="testi-star">
							<i class="fa fa-star active"></i>
							<i class="fa fa-star active"></i>
							<i class="fa fa-star active"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
						</div>												
					<?php } ?>
					
					<?php if( $settings['rating']==2 ){ ?>
						<div class="testi-star">
							<i class="fa fa-star active"></i>
							<i class="fa fa-star active"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							</div>												
						<?php } ?>

						<?php if( $settings['rating']==1 ){ ?>
							<div class="testi-star">
								<i class="fa fa-star active"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
							</div>
						<?php } ?>
					</div>
					
					 <div class="room_pricings">
				    	  <span class="dolar"><?php echo $settings['room_price'];?></span>
				    	  <span class="title"><?php echo $settings['room_price_title'];?></span>
				    </div>
				</div>
				    

					<h3><?php echo $settings['room_title'];?></h3>
					
					
					<div class="iconrapper">
				        <div class="box-icon">
			    	         <?php if($settings['icons_type'] == 'icon' ) : ?>
				             <div class="icon">
				        	    <i class="<?php echo esc_attr($settings['select_icon']['value']); ?>"></i>
			    	         </div>
			    	         <?php else: ?>
			            	<div class="img-icon">
			     	        	<img src="<?php echo $settings['select_img']['url'];?>" alt="" />
			        	    </div>
			            	<?php endif; ?>
		        	    </div>
		    	
		    	         <h4><?php echo $settings['place_title'];?></h4>
			    	</div>
				
				
					<p><?php echo $settings['room_description'];?></p>
					
					<div class="bottom-content">
				    	<div class="room_btn">
					    	<a href="<?php echo esc_url($settings['button_link']['url']); ?>">
						    	<?php echo $settings['button_text']; ?>
							    <?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ); ?>
							    <i class="flaticon flaticon-right-arrow"></i>
						    </a>
					    </div>
					    
					    <div class="bottom-contentss d-flex align-items-center">
					    <div class="iconrapper-two d-flex align-items-center">
				            <div class="box-icon-two">
			    	            <?php if($settings['icons_type_two'] == 'icon' ) : ?>
				                <div class="icon">
				        	        <i class="<?php echo esc_attr($settings['select_icon_two']['value']); ?>"></i>
			    	            </div>
			    	            <?php else: ?>
			            	    <div class="img-icon">
			     	    	        <img src="<?php echo $settings['select_img_two']['url'];?>" alt="" />
			        	         </div>
			        	         <?php endif; ?>
		        	         </div>
		    	
		    	            <h4><?php echo $settings['plane_title'];?></h4>
				        </div>
				        
				         <div class="iconrapper-two d-flex align-items-center">
				            <div class="box-icon-three">
			    	            <?php if($settings['icons_type_three'] == 'icon' ) : ?>
				                <div class="icon">
				        	        <i class="<?php echo esc_attr($settings['select_icon_three']['value']); ?>"></i>
			    	            </div>
			    	            <?php else: ?>
			            	    <div class="img-icon">
			     	    	        <img src="<?php echo $settings['select_img_three']['url'];?>" alt="" />
			        	         </div>
			        	         <?php endif; ?>
		        	         </div>
		    	
		    	            <h4><?php echo $settings['plane_title_three'];?></h4>
				        </div>
				        
				         <div class="iconrapper-two d-flex align-items-center">
				            <div class="box-icon-four">
			    	            <?php if($settings['icons_type_four'] == 'icon' ) : ?>
				                <div class="icon">
				        	        <i class="<?php echo esc_attr($settings['select_icon_four']['value']); ?>"></i>
			    	            </div>
			    	            <?php else: ?>
			            	    <div class="img-icon">
			     	    	        <img src="<?php echo $settings['select_img_four']['url'];?>" alt="" />
			        	         </div>
			        	         <?php endif; ?>
		        	         </div>
		    	
		    	            <h4><?php echo $settings['plane_title_four'];?></h4>
				        </div>
				        </div>
				        
				    </div>
				
				</div>
			</div>
		<?php }elseif($settings['select_style']=='two'){ ?>
			<div class="service_room style2 <?php if('yes' === $settings['show_active']){echo esc_attr('active');}?>">
				<div class="room_img">
					<img src="<?php echo $settings['single_img_room']['url']; ?>" alt="" />
				</div>
				<div class="service_room_body">
				    <ul class="features">																	
						<?php foreach (  $settings['room_list'] as $item ) { ?>
							<li>
								<img src="<?php echo $settings['room_single_img']['url']; ?>" alt="" />
								<?php echo $item['list_title_room']; ?>
							</li>
						<?php } ?>														
					</ul>
					<h3><?php echo $settings['room_title'];?></h3>
					<p><?php echo $settings['room_description'];?></p>
					<div class="room-btn">
						<a href="<?php echo esc_url($settings['button_link']['url']); ?>">
							<?php echo $settings['button_text']; ?>
							<?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ); ?>
						</a>
					</div>
				</div>
			</div>

		<?php }?>

		<?php

	}
}