<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if(!defined('ABSPATH')) exit;


class PlayMouse extends Widget_Base{

	public function get_name(){
		return "Mouse Button";
	}
	
	public function get_title(){
		return "Mouse Button";
	}
	
	public function get_icon(){
		return "eicon-play";
	}
	public function get_categories(){
		return ['dreamit-category'];
	}

	protected function register_controls(){

		$this->start_controls_section(
			'youtube_section', [
				'label' => __( 'Youtube', 'dreamit-elementor-extension' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'video_text',
			[
				'label' => __( 'Video Title', 'dreamit-elementor-extension' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title', 'dreamit-elementor-extension' ),
				'label_block' => true,
				'default' => __( 'This is the title', 'dreamit-elementor-extension' ),
			]
		);
		$this->add_control(
			'youtube_video_url',
			[
				'label' => __( 'Video URL', 'dreamit-elementor-extension' ),
				'type' => Controls_Manager::URL,
				'label_block' => true,
				'default' => [
					'url' => '#'
				]
			]
		);
		$this->add_control(
			'youtube_video_icon',
			[
				'label' => __( 'Video Icon', 'dreamit-elementor-extension' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-play',
				],
			]
		);
		$this->end_controls_section();

/*
==========
	Style Tab
==========
*/

$this->start_controls_section(
	'style_section',
	[
		'label' => __( 'Style', 'dreamit-elementor-extension' ),
		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
	]
);

$this->add_control(
	'select_style',
	[
		'label' => __( 'Select Style', 'dreamit-elementor-extension' ),
		'type' => \Elementor\Controls_Manager::SELECT,
		'options' => [
			'one' => __( 'One', 'dreamit-elementor-extension' ),
			'two' => __( 'Two', 'dreamit-elementor-extension' ),
			'three' => __( 'Three', 'dreamit-elementor-extension' ),
		],
		'default' => 'one',

	]
);
$this->add_responsive_control(
	'text_align',
	[
		'label' => __( 'Alignment', 'dreamit-elementor-extension' ),
		'type' => \Elementor\Controls_Manager::CHOOSE,
		'options' => [
			'left' => [
				'title' => __( 'Left', 'dreamit-elementor-extension' ),
				'icon' => 'eicon-text-align-left',
			],
			'center' => [
				'title' => __( 'Center', 'dreamit-elementor-extension' ),
				'icon' => 'eicon-text-align-center',
			],
			'right' => [
				'title' => __( 'Right', 'dreamit-elementor-extension' ),
				'icon' => 'eicon-text-align-right',
			],
			'justify' => [
				'title' => __( 'Justified', 'dreamit-elementor-extension' ),
				'icon' => 'eicon-text-align-justify',
			],
		],
		'selectors' => [
			'{{WRAPPER}} .service-box' => 'text-align: {{VALUE}};',
		],
	]
);
$this->end_controls_section();
$this->start_controls_section(
	'title_section_style',
	[
		'label' => __( 'Title', 'dreamit-elementor-extension' ),
		'tab' => \Elementor\Controls_Manager::TAB_STYLE,
	]
);

$this->add_control(
	'title_color',
	[
		'label' => __( 'Color', 'dreamit-elementor-extension' ),
		'type' => \Elementor\Controls_Manager::COLOR,
		'default' => '',
		'selectors' => [
			'{{WRAPPER}} .video__area .video__content span' => 'color: {{VALUE}};',
		],
	]
);
$this->add_group_control(
	\Elementor\Group_Control_Typography::get_type(),
	[
		'name' => 'title_typography',
		'selector' => '{{WRAPPER}} .video__area .video__content span, {{WRAPPER}} .elementor-icon-box-content .elementor-icon-box-title a',
	]
);
$this->add_responsive_control(
	'title_margin',
	[
		'label' => __( 'Margin', 'dreamit-elementor-extension' ),
		'type' => \Elementor\Controls_Manager::DIMENSIONS,
		'size_units' => [ 'px', 'em', '%' ],
		'selectors' => [
			'{{WRAPPER}} .video__area .video__content span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
		],
	]
);
$this->end_controls_section();

}

protected function render(){

	$settings = $this->get_settings_for_display();

	?>
	
	
<?php if($settings['select_style']=='one'){ ?>
	<!-- MAIN SECTION FOR PLAY BUTTON -->

	<div class="cursor video" id="video_cursor"><?php echo $settings['video_text'];?></div>
	  <section class="video__area">
	    <div class="video__content">
	      <a class=" video-vemo-icon venobox vbox-item" data-vbtype="youtube" data-autoplay="true" href="<?php echo $settings['youtube_video_url']['url']; ?>"><?php \Elementor\Icons_Manager::render_icon( $settings['youtube_video_icon'], [ 'aria-hidden' => 'true' ] ); ?> <span class="play-now"><?php echo $settings['video_text'];?></span></a>
	    </div>
	  </section>

	<?php }
	elseif($settings['select_style']=='three'){ ?>
	
	<div class=" style2">
	    <div class="cursor video" id="video_cursor"><?php echo $settings['video_text'];?></div>
	    <section class="video__area">
	        <div class="video__content">
	        <a class=" video-vemo-icon venobox vbox-item" data-vbtype="youtube" data-autoplay="true" href="<?php echo $settings['youtube_video_url']['url']; ?>"><?php \Elementor\Icons_Manager::render_icon( $settings['youtube_video_icon'], [ 'aria-hidden' => 'true' ] ); ?> <span class="play-now"><?php echo $settings['video_text'];?></span></a>
	        </div>
	    </section>
	  </div>
	  <?php }
    }

}













